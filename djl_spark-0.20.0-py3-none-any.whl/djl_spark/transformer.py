#!/usr/bin/env python
#
# Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file
# except in compliance with the License. A copy of the License is located at
#
# http://aws.amazon.com/apache2.0/
#
# or in the "LICENSE.txt" file accompanying this file. This file is distributed on an "AS IS"
# BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, express or implied. See the License for
# the specific language governing permissions and limitations under the License.

from pyspark import SparkContext


class SparkTransformer:

    def __init__(self, input_col, output_col, model_url, output_class, translator):
        self.input_col = input_col
        self.output_col = output_col
        self.model_url = model_url
        self.output_class = output_class
        self.translator = translator

    def transform(self, dataset):
        sc = SparkContext._active_spark_context
        translator = sc._jvm.ai.djl.spark.translator.SparkImageClassificationTranslator()
        clazz = sc._jvm.java.lang.Class.forName(self.output_class)

        transformer = sc._jvm.ai.djl.spark.SparkTransformer() \
            .setInputCol(self.input_col) \
            .setOutputCol(self.output_col) \
            .setModelUrl(self.model_url) \
            .setOutputClass(clazz) \
            .setTranslator(translator)
        return transformer.transform(dataset)
